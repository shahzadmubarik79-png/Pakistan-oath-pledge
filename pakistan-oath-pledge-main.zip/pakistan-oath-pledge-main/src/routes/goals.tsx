import { createFileRoute, Link } from "@tanstack/react-router";
import {
  GraduationCap, Leaf, Trees, Cpu, Users, Sparkles, HeartHandshake,
  TrafficCone, ShieldCheck, Recycle, Stethoscope, Flag,
} from "lucide-react";

export const Route = createFileRoute("/goals")({
  head: () => ({
    meta: [
      { title: "National Goals — Pakistan Pledge" },
      { name: "description", content: "The twelve national goals at the heart of the Pakistan Pledge & Commitment initiative." },
      { property: "og:url", content: "/goals" },
    ],
    links: [{ rel: "canonical", href: "/goals" }],
  }),
  component: GoalsPage,
});

const GOALS = [
  { icon: GraduationCap, title: "Education For All", desc: "Universal access to quality learning, from primary schools to digital literacy." },
  { icon: Recycle, title: "Clean Pakistan", desc: "Cleaner streets, cities and rivers through citizen-led action." },
  { icon: Trees, title: "Tree Plantation", desc: "Greener provinces — one billion saplings, one nation at a time." },
  { icon: Cpu, title: "Digital Pakistan", desc: "Empowering youth with technology, skills and the digital economy." },
  { icon: Sparkles, title: "Women's Empowerment", desc: "Equal opportunity in education, work and civic leadership." },
  { icon: Users, title: "Youth Development", desc: "Investing in the leaders, makers and creators of tomorrow." },
  { icon: HeartHandshake, title: "Community Welfare", desc: "Neighbourhoods built on dignity, kindness and shared responsibility." },
  { icon: TrafficCone, title: "Road Safety", desc: "Responsible driving and safer roads for every family." },
  { icon: ShieldCheck, title: "Anti-Corruption", desc: "Honesty, transparency and accountability in every act." },
  { icon: Leaf, title: "Environmental Protection", desc: "Protecting rivers, glaciers and the air we share." },
  { icon: Stethoscope, title: "Healthcare Awareness", desc: "Healthy families through prevention, awareness and access." },
  { icon: Flag, title: "National Unity", desc: "One people across provinces, languages and beliefs." },
];

function GoalsPage() {
  return (
    <section className="container-page py-16 md:py-24">
      <div className="text-xs uppercase tracking-widest text-flag-green font-semibold">
        National Goals
      </div>
      <h1 className="display mt-3 text-4xl md:text-6xl font-bold text-primary leading-tight max-w-3xl">
        Twelve pillars for a stronger Pakistan.
      </h1>
      <p className="mt-5 max-w-2xl text-muted-foreground text-lg">
        Each pledge made on this platform contributes to twelve focused national
        priorities. These are commitments every citizen — regardless of
        background — can carry into daily life.
      </p>

      <div className="mt-14 grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
        {GOALS.map((g) => (
          <div key={g.title} className="group relative overflow-hidden rounded-xl border bg-card p-7 hover:-translate-y-1 hover:shadow-elegant transition-all">
            <div className="absolute -right-8 -top-8 h-28 w-28 rounded-full bg-flag-green/5 group-hover:bg-flag-green/10 transition-colors" />
            <div className="relative">
              <div className="h-12 w-12 rounded-lg gradient-green text-primary-foreground flex items-center justify-center">
                <g.icon className="h-6 w-6" />
              </div>
              <div className="mt-5 font-display text-xl font-semibold text-primary">{g.title}</div>
              <div className="mt-2 text-sm text-muted-foreground leading-relaxed">{g.desc}</div>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-16 text-center">
        <Link to="/pledge" className="inline-flex rounded-full gradient-green text-primary-foreground px-7 py-3.5 text-sm font-semibold shadow-elegant">
          Pledge to these goals
        </Link>
      </div>
    </section>
  );
}
