import { createFileRoute, Link } from "@tanstack/react-router";
import monuments from "@/assets/monuments-line.png";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "About — Pakistan Pledge & Commitment" },
      { name: "description", content: "The story, values and vision behind the Pakistan Pledge & Commitment national initiative." },
      { property: "og:url", content: "/about" },
    ],
    links: [{ rel: "canonical", href: "/about" }],
  }),
  component: AboutPage,
});

function AboutPage() {
  return (
    <section className="container-page py-16 md:py-24">
      <div className="grid md:grid-cols-12 gap-12">
        <div className="md:col-span-7">
          <div className="text-xs uppercase tracking-widest text-flag-green font-semibold">
            About the Initiative
          </div>
          <h1 className="display mt-3 text-4xl md:text-6xl font-bold text-primary leading-tight">
            A movement of Pakistanis, for Pakistan.
          </h1>
          <div className="mt-7 space-y-5 text-foreground/85 leading-relaxed">
            <p>
              Pakistan Pledge &amp; Commitment is a non-political national
              initiative that invites every Pakistani — at home and abroad —
              to make a public, personal commitment to the values that build a
              great nation: honesty, education, unity, service and care for
              our environment.
            </p>
            <p>
              Our platform issues every signatory a verifiable certificate with
              a unique pledge ID and QR code, so that each pledge becomes a
              lasting, shareable act of citizenship.
            </p>
            <p>
              From the foothills of Gilgit to the coast of Gwadar, we believe
              the future of Pakistan is written by its people — one pledge at a
              time.
            </p>
          </div>

          <div className="mt-9 flex flex-wrap gap-3">
            <Link to="/pledge" className="inline-flex rounded-full gradient-green text-primary-foreground px-6 py-3 text-sm font-semibold shadow-elegant">
              Take the pledge
            </Link>
            <Link to="/goals" className="inline-flex rounded-full border border-primary/30 text-primary px-6 py-3 text-sm font-semibold hover:bg-primary/5">
              National goals
            </Link>
          </div>
        </div>

        <aside className="md:col-span-5 space-y-4">
          {[
            { k: "Founded", v: "By citizens, for citizens" },
            { k: "Reach", v: "All 4 provinces, AJK, GB & ICT" },
            { k: "Certificates issued", v: "100,000+ and counting" },
            { k: "Languages", v: "English & Urdu (coming soon)" },
          ].map((row) => (
            <div key={row.k} className="rounded-xl border bg-card p-5 flex items-center justify-between">
              <div className="text-xs uppercase tracking-widest text-muted-foreground">{row.k}</div>
              <div className="text-sm font-semibold text-primary">{row.v}</div>
            </div>
          ))}
        </aside>
      </div>

      <img
        src={monuments}
        alt="Pakistan national monuments"
        loading="lazy"
        width={1920}
        height={400}
        className="mt-16 mx-auto w-full max-w-5xl opacity-60"
      />
    </section>
  );
}
