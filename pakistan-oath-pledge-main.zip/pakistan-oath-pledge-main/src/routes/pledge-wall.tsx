import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo } from "react";
import { allPledges, PROVINCES } from "@/lib/pledge-store";
import { useMounted } from "@/hooks/use-mounted";
import { motion } from "framer-motion";
import { MapPin, Calendar, Award } from "lucide-react";

export const Route = createFileRoute("/pledge-wall")({
  head: () => ({
    meta: [
      { title: "Pledge Wall — Pakistan Pledge" },
      { name: "description", content: "See pledges from Pakistanis across every province, updated in real time." },
      { property: "og:url", content: "/pledge-wall" },
    ],
    links: [{ rel: "canonical", href: "/pledge-wall" }],
  }),
  component: WallPage,
});

const SEED = [
  ["Ayesha", "Lahore", "Punjab"],
  ["Bilal", "Karachi", "Sindh"],
  ["Hina", "Peshawar", "Khyber Pakhtunkhwa"],
  ["Zain", "Quetta", "Balochistan"],
  ["Sara", "Islamabad", "Islamabad Capital Territory"],
  ["Usman", "Gilgit", "Gilgit Baltistan"],
  ["Fatima", "Multan", "Punjab"],
  ["Hamza", "Hyderabad", "Sindh"],
  ["Mehwish", "Faisalabad", "Punjab"],
  ["Imran", "Mirpur", "Azad Jammu & Kashmir"],
  ["Noor", "Rawalpindi", "Punjab"],
  ["Yousuf", "Sialkot", "Punjab"],
] as const;

function WallPage() {
  const mounted = useMounted();
  const items = useMemo(() => {
    const real = mounted
      ? allPledges().slice(0, 24).map((p) => ({
          name: p.fullName.split(" ")[0],
          city: p.city,
          province: p.province,
          date: new Date(p.createdAt),
        }))
      : [];
    const seeded = SEED.map(([name, city, province], i) => ({
      name, city, province,
      date: new Date(Date.now() - i * 6 * 3600 * 1000),
    }));
    return [...real, ...seeded];
  }, [mounted]);

  return (
    <section className="container-page py-16 md:py-20">
      <div className="text-xs uppercase tracking-widest text-flag-green font-semibold">
        Pledge Wall
      </div>
      <h1 className="display mt-3 text-4xl md:text-5xl font-bold text-primary leading-tight">
        A living wall of Pakistani commitments.
      </h1>
      <p className="mt-4 text-muted-foreground max-w-2xl">
        Every name below represents a Pakistani who chose to stand up for the
        future of our country.
      </p>

      <div className="mt-10 flex flex-wrap gap-2">
        {PROVINCES.map((p) => (
          <span key={p} className="rounded-full border bg-card px-3 py-1 text-xs text-foreground/80">
            {p}
          </span>
        ))}
      </div>

      <div className="mt-10 grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {items.map((it, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, y: 12 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.4, delay: (i % 8) * 0.04 }}
            className="group rounded-xl border bg-card p-5 hover:shadow-elegant transition-shadow"
          >
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-full gradient-green text-primary-foreground flex items-center justify-center font-display font-semibold">
                {it.name.slice(0, 1)}
              </div>
              <div>
                <div className="font-semibold text-foreground">{it.name}</div>
                <div className="text-xs text-muted-foreground flex items-center gap-1">
                  <MapPin className="h-3 w-3" /> {it.city}, {it.province}
                </div>
              </div>
              <div className="ml-auto rounded-full bg-flag-green/10 text-flag-green p-1.5">
                <Award className="h-4 w-4" />
              </div>
            </div>
            <div className="mt-4 flex items-center justify-between text-xs text-muted-foreground">
              <span className="inline-flex items-center gap-1">
                <Calendar className="h-3 w-3" />
                {it.date.toLocaleDateString("en-GB")}
              </span>
              <span className="font-medium text-flag-green">Pledged</span>
            </div>
          </motion.div>
        ))}
      </div>

      <div className="mt-14 text-center">
        <Link to="/pledge" className="inline-flex items-center gap-2 rounded-full gradient-green text-primary-foreground px-7 py-3.5 text-sm font-semibold shadow-elegant">
          Add your name to the wall
        </Link>
      </div>
    </section>
  );
}
