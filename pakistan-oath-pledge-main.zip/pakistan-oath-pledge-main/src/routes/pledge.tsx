import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { motion } from "framer-motion";
import { addPledge, PROVINCES } from "@/lib/pledge-store";
import { ArrowRight, ShieldCheck } from "lucide-react";

export const Route = createFileRoute("/pledge")({
  head: () => ({
    meta: [
      { title: "Take the Pakistan Pledge" },
      { name: "description", content: "Sign the Pakistan Pledge & Commitment and receive your official certificate with QR verification." },
      { property: "og:title", content: "Take the Pakistan Pledge" },
      { property: "og:description", content: "Sign the Pakistan Pledge & Commitment and receive your official certificate." },
      { property: "og:url", content: "/pledge" },
    ],
    links: [{ rel: "canonical", href: "/pledge" }],
  }),
  component: PledgePage,
});

const initial = {
  fullName: "", fatherName: "", email: "",
  gender: "Male", province: "Punjab", city: "",
};

function PledgePage() {
  const navigate = useNavigate();
  const [form, setForm] = useState(initial);
  const [agreed, setAgreed] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  function update<K extends keyof typeof initial>(k: K, v: string) {
    setForm((f) => ({ ...f, [k]: v }));
  }

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    if (!agreed) { setError("Please accept the pledge to continue."); return; }
    if (form.fullName.trim().length < 2) { setError("Please enter your full name."); return; }
    if (!/^\S+@\S+\.\S+$/.test(form.email)) { setError("Please enter a valid email."); return; }
    setSubmitting(true);
    const pledge = addPledge(form);
    await new Promise((r) => setTimeout(r, 350));
    navigate({ to: "/success", search: { id: pledge.id } });
  }

  return (
    <section className="container-page py-14 md:py-20">
      <div className="grid lg:grid-cols-12 gap-10">
        <motion.aside
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5 }}
          className="lg:col-span-5"
        >
          <div className="text-xs uppercase tracking-widest text-flag-green font-semibold">
            Pakistan Pledge
          </div>
          <h1 className="display mt-3 text-4xl md:text-5xl font-bold text-primary leading-tight">
            Pledge your commitment to Pakistan.
          </h1>
          <p className="mt-5 text-muted-foreground leading-relaxed">
            Your details are used only to issue your official certificate and
            verify your pledge. Each pledge receives a unique ID and a QR code
            that anyone can verify.
          </p>
          <div className="mt-8 rounded-2xl border bg-card p-6 ring-gold">
            <div className="font-serif text-lg leading-relaxed text-foreground/90">
              <span className="text-gold text-2xl font-display leading-none">“</span>
              I solemnly pledge that I will contribute positively towards the
              development, prosperity, unity, peace and progress of Pakistan.
              I will respect the law, protect the environment, promote
              education, support my community, and serve my country with
              honesty and dedication.
              <span className="text-gold text-2xl font-display leading-none">”</span>
            </div>
          </div>
          <div className="mt-6 flex items-center gap-2 text-xs text-muted-foreground">
            <ShieldCheck className="h-4 w-4 text-flag-green" />
            Your data is stored privately on your device for this preview.
          </div>
        </motion.aside>

        <motion.form
          onSubmit={onSubmit}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.1 }}
          className="lg:col-span-7 rounded-2xl border bg-card p-7 md:p-9 shadow-elegant space-y-5"
        >
          <div className="grid sm:grid-cols-2 gap-4">
            <Field label="Full Name" value={form.fullName} onChange={(v) => update("fullName", v)} required />
            <Field label="Father's Name" value={form.fatherName} onChange={(v) => update("fatherName", v)} />
            <Field label="Email Address" type="email" value={form.email} onChange={(v) => update("email", v)} required />
            <Select label="Gender" value={form.gender} onChange={(v) => update("gender", v)} options={["Male","Female","Other"]} />
            <Select label="Province" value={form.province} onChange={(v) => update("province", v)} options={PROVINCES} />
            <Field label="City" value={form.city} onChange={(v) => update("city", v)} required />
          </div>

          <label className="flex items-start gap-3 rounded-lg border bg-secondary/40 p-4 cursor-pointer">
            <input
              type="checkbox"
              checked={agreed}
              onChange={(e) => setAgreed(e.target.checked)}
              className="mt-1 h-4 w-4 accent-primary"
            />
            <span className="text-sm text-foreground/90">
              I agree and accept this pledge, and I confirm the information
              above is accurate to the best of my knowledge.
            </span>
          </label>

          {error && (
            <div className="rounded-md border border-destructive/30 bg-destructive/10 px-4 py-2.5 text-sm text-destructive">
              {error}
            </div>
          )}

          <div className="flex items-center justify-between pt-2">
            <Link to="/" className="text-sm text-muted-foreground hover:text-primary">
              ← Back
            </Link>
            <button
              type="submit"
              disabled={submitting}
              className="inline-flex items-center gap-2 rounded-full gradient-green text-primary-foreground px-7 py-3.5 text-sm font-semibold shadow-elegant disabled:opacity-60"
            >
              {submitting ? "Submitting…" : "Take My Pledge"}
              <ArrowRight className="h-4 w-4" />
            </button>
          </div>
        </motion.form>
      </div>
    </section>
  );
}

function Field({
  label, value, onChange, type = "text", required, placeholder,
}: {
  label: string; value: string; onChange: (v: string) => void;
  type?: string; required?: boolean; placeholder?: string;
}) {
  return (
    <label className="block">
      <span className="text-xs font-medium text-foreground/70 uppercase tracking-wider">
        {label}{required && <span className="text-destructive"> *</span>}
      </span>
      <input
        type={type}
        value={value}
        required={required}
        placeholder={placeholder}
        onChange={(e) => onChange(e.target.value)}
        className="mt-1.5 w-full rounded-md border bg-background px-3.5 py-2.5 text-sm outline-none transition-shadow focus:ring-2 focus:ring-primary/30 focus:border-primary"
      />
    </label>
  );
}

function Select({
  label, value, onChange, options,
}: {
  label: string; value: string; onChange: (v: string) => void; options: string[];
}) {
  return (
    <label className="block">
      <span className="text-xs font-medium text-foreground/70 uppercase tracking-wider">{label}</span>
      <select
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="mt-1.5 w-full rounded-md border bg-background px-3.5 py-2.5 text-sm outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary"
      >
        {options.map((o) => <option key={o} value={o}>{o}</option>)}
      </select>
    </label>
  );
}
