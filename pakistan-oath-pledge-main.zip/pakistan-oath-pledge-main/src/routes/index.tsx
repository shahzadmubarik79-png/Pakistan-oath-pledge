import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import {
  GraduationCap, Leaf, Trees, Cpu, Users, Sparkles, HeartHandshake,
  TrafficCone, ShieldCheck, Recycle, Stethoscope, Flag, ArrowRight, CheckCircle2,
} from "lucide-react";
import heroFlag from "@/assets/hero-flag.jpg";
import monuments from "@/assets/monuments-line.png";
import { stats } from "@/lib/pledge-store";
import { useMounted } from "@/hooks/use-mounted";
import { useI18n } from "@/lib/i18n";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Pakistan Pledge & Commitment — Join the National Initiative" },
      { name: "description", content: "Take the Pakistan Pledge: commit to unity, education, environment, and national development. Receive an official certificate with QR verification." },
      { property: "og:title", content: "Pakistan Pledge & Commitment" },
      { property: "og:description", content: "Join millions of Pakistanis in building a stronger, cleaner, educated and united Pakistan." },
      { property: "og:url", content: "/" },
    ],
    links: [{ rel: "canonical", href: "/" }],
  }),
  component: HomePage,
});

const GOALS = [
  { icon: GraduationCap, title: "Education For All", desc: "Universal access to quality learning, from primary schools to digital literacy." },
  { icon: Recycle, title: "Clean Pakistan", desc: "Cleaner streets, cities and rivers through citizen-led action." },
  { icon: Trees, title: "Tree Plantation", desc: "Greener provinces — one billion saplings, one nation at a time." },
  { icon: Cpu, title: "Digital Pakistan", desc: "Empowering youth with technology, skills and the digital economy." },
  { icon: Sparkles, title: "Women's Empowerment", desc: "Equal opportunity in education, work and civic leadership." },
  { icon: Users, title: "Youth Development", desc: "Investing in the leaders, makers and creators of tomorrow." },
  { icon: HeartHandshake, title: "Community Welfare", desc: "Neighbourhoods built on dignity, kindness and shared responsibility." },
  { icon: TrafficCone, title: "Road Safety", desc: "Responsible driving and safer roads for every family." },
  { icon: ShieldCheck, title: "Anti-Corruption", desc: "Honesty, transparency and accountability in every act." },
  { icon: Leaf, title: "Environmental Protection", desc: "Protecting rivers, glaciers and the air we share." },
  { icon: Stethoscope, title: "Healthcare Awareness", desc: "Healthy families through prevention, awareness and access." },
  { icon: Flag, title: "National Unity", desc: "One people across provinces, languages and beliefs." },
];

function HomePage() {
  return (
    <div>
      <Hero />
      <StatsBar />
      <AboutInitiative />
      <GoalsSection />
      <PledgeCTA />
    </div>
  );
}

function Hero() {
  const { t } = useI18n();
  return (
    <section className="relative isolate overflow-hidden">
      <div className="absolute inset-0 -z-10">
        <img
          src={heroFlag}
          alt="Waving Pakistan flag"
          className="h-full w-full object-cover flag-wave"
          width={1920}
          height={1280}
        />
        <div className="absolute inset-0 bg-gradient-to-r from-background/95 via-background/80 to-background/40" />
        <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent to-transparent" />
      </div>

      <div className="container-page pt-20 pb-28 md:pt-28 md:pb-36 grid md:grid-cols-12 gap-10 items-center">
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, ease: "easeOut" }}
          className="md:col-span-7"
        >
          <div className="inline-flex items-center gap-2 rounded-full border border-primary/20 bg-primary/5 px-3 py-1 text-xs font-medium text-primary">
            <span className="h-1.5 w-1.5 rounded-full bg-flag-green animate-pulse" />
            {t("hero.badge")}
          </div>
          <h1 className="display mt-6 text-5xl md:text-7xl font-bold leading-[1.02] text-primary">
            {t("hero.title1")}
            <br />
            <span className="text-foreground">{t("hero.title2")}</span>
            <span className="text-gradient-gold">{t("hero.title3")}</span>
          </h1>
          <p className="mt-6 max-w-xl text-lg text-muted-foreground leading-relaxed">
            {t("hero.desc")}
          </p>
          <div className="mt-9 flex flex-wrap items-center gap-3">
            <Link
              to="/pledge"
              className="group inline-flex items-center gap-2 rounded-full gradient-green text-primary-foreground px-7 py-3.5 text-sm font-semibold shadow-elegant hover:opacity-95"
            >
              {t("cta.take")}
              <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
            </Link>
            <Link
              to="/goals"
              className="inline-flex items-center gap-2 rounded-full border border-primary/30 bg-background/70 backdrop-blur px-6 py-3.5 text-sm font-semibold text-primary hover:bg-primary/5"
            >
              {t("hero.viewGoals")}
            </Link>
            <Link
              to="/about"
              className="inline-flex items-center gap-1 px-2 py-3.5 text-sm font-medium text-muted-foreground hover:text-primary"
            >
              {t("hero.learnMore")} <ArrowRight className="h-3.5 w-3.5" />
            </Link>
          </div>
          <div className="mt-10 flex items-center gap-6 text-xs text-muted-foreground">
            {[t("hero.bullet1"), t("hero.bullet2"), t("hero.bullet3")].map((tx) => (
              <div key={tx} className="flex items-center gap-2">
                <CheckCircle2 className="h-4 w-4 text-flag-green" />
                {tx}
              </div>
            ))}
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="md:col-span-5"
        >
          <PledgeCard />
        </motion.div>
      </div>
    </section>
  );
}

function PledgeCard() {
  const { t } = useI18n();
  return (
    <div className="relative rounded-2xl bg-card/95 backdrop-blur ring-gold shadow-elegant p-7 md:p-8">
      <div className="absolute -top-3 left-7 rounded-full gradient-green px-3 py-1 text-[10px] uppercase tracking-widest text-primary-foreground">
        {t("pledge.badge")}
      </div>
      <div className="font-serif text-xl md:text-2xl leading-relaxed text-foreground/90">
        <span className="text-gold text-3xl font-display leading-none">“</span>
        {t("pledge.quote")}
        <span className="text-gold text-3xl font-display leading-none">”</span>
      </div>
      <div className="mt-6 flex items-center justify-between border-t pt-4">
        <div className="text-xs text-muted-foreground">Today's pledges grow by the minute</div>
        <Link to="/pledge" className="text-sm font-semibold text-primary inline-flex items-center gap-1">
          {t("pledge.signNow")} <ArrowRight className="h-3.5 w-3.5" />
        </Link>
      </div>
    </div>
  );
}

function useCount(target: number, duration = 1400) {
  const [n, setN] = useState(0);
  useEffect(() => {
    let raf = 0;
    const start = performance.now();
    const tick = (t: number) => {
      const p = Math.min(1, (t - start) / duration);
      setN(Math.floor(target * (1 - Math.pow(1 - p, 3))));
      if (p < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [target, duration]);
  return n;
}

function StatItem({ label, value }: { label: string; value: number }) {
  const n = useCount(value);
  return (
    <div className="text-center md:text-left">
      <div className="font-display text-3xl md:text-4xl font-bold text-primary">
        {n.toLocaleString()}
      </div>
      <div className="mt-1 text-xs uppercase tracking-widest text-muted-foreground">{label}</div>
    </div>
  );
}

function StatsBar() {
  const mounted = useMounted();
  const s = mounted ? stats() : { total: 128473, verified: 128473, cities: 91, provinces: 7, today: 312 };
  return (
    <section className="border-y border-border/60 bg-gradient-to-b from-secondary/40 to-background">
      <div className="container-page py-10 grid grid-cols-2 md:grid-cols-5 gap-8">
        <StatItem label="Total Pledges" value={s.total} />
        <StatItem label="Verified Citizens" value={s.verified} />
        <StatItem label="Participating Cities" value={s.cities} />
        <StatItem label="Provinces" value={s.provinces} />
        <StatItem label="Today's Pledges" value={s.today} />
      </div>
    </section>
  );
}

function AboutInitiative() {
  const cards = [
    { icon: Flag, title: "National Responsibility", desc: "A personal commitment to the duties we owe our country." },
    { icon: Users, title: "Active Citizenship", desc: "Civic action that strengthens institutions and communities." },
    { icon: HeartHandshake, title: "Community Participation", desc: "Local impact through volunteerism and service." },
    { icon: Sparkles, title: "Vision for Pakistan", desc: "A future shaped by honesty, education and unity." },
  ];
  return (
    <section className="container-page py-20 md:py-28">
      <div className="grid md:grid-cols-12 gap-10">
        <div className="md:col-span-5">
          <div className="text-xs uppercase tracking-widest text-flag-green font-semibold">
            About the Initiative
          </div>
          <h2 className="display mt-3 text-4xl md:text-5xl font-bold text-primary leading-tight">
            A pledge written by the people, for the people.
          </h2>
          <p className="mt-5 text-muted-foreground leading-relaxed">
            Pakistan Pledge &amp; Commitment is a non-political, citizen-led
            movement inviting every Pakistani — at home and abroad — to put
            their name behind the values that shape a great nation.
          </p>
          <Link
            to="/about"
            className="mt-7 inline-flex items-center gap-2 text-sm font-semibold text-primary hover:gap-3 transition-all"
          >
            Read our charter <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
        <div className="md:col-span-7 grid sm:grid-cols-2 gap-4">
          {cards.map((c) => (
            <div key={c.title} className="group rounded-xl border bg-card p-6 hover:shadow-elegant transition-shadow">
              <div className="h-11 w-11 rounded-lg gradient-green text-primary-foreground flex items-center justify-center">
                <c.icon className="h-5 w-5" />
              </div>
              <div className="mt-4 font-display text-lg font-semibold text-primary">{c.title}</div>
              <div className="mt-1.5 text-sm text-muted-foreground leading-relaxed">{c.desc}</div>
            </div>
          ))}
        </div>
      </div>

      <img
        src={monuments}
        alt="Pakistan monuments illustration"
        loading="lazy"
        width={1920}
        height={400}
        className="mt-16 mx-auto w-full max-w-5xl opacity-60"
      />
    </section>
  );
}

function GoalsSection() {
  return (
    <section className="bg-gradient-to-b from-secondary/40 via-background to-background py-20 md:py-28">
      <div className="container-page">
        <div className="max-w-2xl">
          <div className="text-xs uppercase tracking-widest text-flag-green font-semibold">
            National Goals
          </div>
          <h2 className="display mt-3 text-4xl md:text-5xl font-bold text-primary leading-tight">
            Twelve commitments. One Pakistan.
          </h2>
          <p className="mt-4 text-muted-foreground">
            Each pledge contributes to twelve focused national goals — the
            pillars of a stronger, fairer and greener tomorrow.
          </p>
        </div>

        <div className="mt-12 grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {GOALS.map((g, i) => (
            <motion.div
              key={g.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-80px" }}
              transition={{ duration: 0.5, delay: (i % 6) * 0.05 }}
              className="group relative overflow-hidden rounded-xl border bg-card p-6 hover:-translate-y-1 hover:shadow-elegant transition-all"
            >
              <div className="absolute -right-6 -top-6 h-24 w-24 rounded-full bg-flag-green/5 group-hover:bg-flag-green/10 transition-colors" />
              <div className="relative">
                <div className="h-11 w-11 rounded-lg bg-primary/10 text-primary flex items-center justify-center">
                  <g.icon className="h-5 w-5" />
                </div>
                <div className="mt-4 font-display text-lg font-semibold text-primary">{g.title}</div>
                <div className="mt-1.5 text-sm text-muted-foreground leading-relaxed">{g.desc}</div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

function PledgeCTA() {
  return (
    <section className="container-page py-20">
      <div className="relative overflow-hidden rounded-3xl gradient-green text-primary-foreground p-10 md:p-16 shadow-elegant">
        <div className="absolute inset-0 opacity-[0.08] mix-blend-overlay">
          <img src={heroFlag} alt="" className="h-full w-full object-cover" />
        </div>
        <div className="relative max-w-2xl">
          <div className="text-xs uppercase tracking-[0.25em] text-gold font-semibold">
            Stand up for Pakistan
          </div>
          <h3 className="display mt-3 text-3xl md:text-5xl font-bold leading-tight">
            Add your name to the National Pledge today.
          </h3>
          <p className="mt-4 text-primary-foreground/85 max-w-lg">
            Receive a personalised certificate with a unique pledge ID and QR
            verification — proof of your commitment to Pakistan.
          </p>
          <Link
            to="/pledge"
            className="mt-8 inline-flex items-center gap-2 rounded-full bg-background text-primary px-7 py-3.5 text-sm font-semibold hover:bg-background/90"
          >
            Take The Pledge <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
      </div>
    </section>
  );
}
