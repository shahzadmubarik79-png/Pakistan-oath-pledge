import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { findPledge, type Pledge } from "@/lib/pledge-store";
import { downloadCertificate } from "@/lib/certificate";
import { CheckCircle2, Search, XCircle, Download } from "lucide-react";

export const Route = createFileRoute("/verify")({
  validateSearch: (s: Record<string, unknown>) => ({ id: s.id ? String(s.id) : "" }),
  head: () => ({
    meta: [
      { title: "Verify Certificate — Pakistan Pledge" },
      { name: "description", content: "Verify the authenticity of a Pakistan Pledge & Commitment certificate by Pledge ID, name or CNIC." },
      { property: "og:url", content: "/verify" },
    ],
    links: [{ rel: "canonical", href: "/verify" }],
  }),
  component: VerifyPage,
});

function VerifyPage() {
  const { id: initialId } = Route.useSearch();
  const [query, setQuery] = useState(initialId ?? "");
  const [result, setResult] = useState<Pledge | null | undefined>(undefined);

  useEffect(() => {
    if (initialId) setResult(findPledge(initialId) ?? null);
  }, [initialId]);

  function onSearch(e: React.FormEvent) {
    e.preventDefault();
    setResult(findPledge(query) ?? null);
  }

  return (
    <section className="container-page py-16 md:py-24 max-w-3xl">
      <div className="text-xs uppercase tracking-widest text-flag-green font-semibold">
        Verification System
      </div>
      <h1 className="display mt-3 text-4xl md:text-5xl font-bold text-primary">
        Verify a Pakistan Pledge.
      </h1>
      <p className="mt-4 text-muted-foreground">
        Enter a Pledge ID, full name, or CNIC to authenticate a certificate.
      </p>

      <form onSubmit={onSearch} className="mt-8 flex gap-2">
        <div className="relative flex-1">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="e.g. PK-2026-AB12CD"
            className="w-full rounded-full border bg-background pl-10 pr-4 py-3.5 text-sm outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary"
          />
        </div>
        <button className="inline-flex items-center gap-2 rounded-full gradient-green text-primary-foreground px-6 py-3.5 text-sm font-semibold shadow-elegant">
          Verify
        </button>
      </form>

      {result === undefined ? null : result ? (
        <div className="mt-10 rounded-2xl border bg-card p-8 shadow-elegant ring-gold">
          <div className="flex items-center gap-3 text-flag-green">
            <CheckCircle2 className="h-6 w-6" />
            <span className="font-semibold">Certificate verified — authentic.</span>
          </div>
          <div className="mt-6 grid sm:grid-cols-2 gap-5">
            <Info label="Certificate Status" value="Verified" />
            <Info label="Pledge ID" value={result.id} mono />
            <Info label="Citizen Name" value={result.fullName} />
            <Info label="Province" value={result.province} />
            <Info label="City" value={result.city} />
            <Info label="Issue Date" value={new Date(result.createdAt).toLocaleDateString("en-GB")} />
          </div>
          <button
            onClick={() => downloadCertificate(result)}
            className="mt-7 inline-flex items-center gap-2 rounded-full border border-primary/30 text-primary px-5 py-2.5 text-sm font-semibold hover:bg-primary/5"
          >
            <Download className="h-4 w-4" /> Download certificate
          </button>
        </div>
      ) : (
        <div className="mt-10 rounded-2xl border bg-card p-8">
          <div className="flex items-center gap-3 text-destructive">
            <XCircle className="h-6 w-6" />
            <span className="font-semibold">No matching pledge found.</span>
          </div>
          <p className="mt-2 text-sm text-muted-foreground">
            Check the Pledge ID and try again. IDs look like <span className="font-mono">PK-2026-AB12CD</span>.
          </p>
        </div>
      )}
    </section>
  );
}

function Info({ label, value, mono }: { label: string; value: string; mono?: boolean }) {
  return (
    <div>
      <div className="text-[10px] uppercase tracking-widest text-muted-foreground">{label}</div>
      <div className={`mt-1 text-sm font-semibold text-foreground ${mono ? "font-mono" : ""}`}>{value}</div>
    </div>
  );
}
