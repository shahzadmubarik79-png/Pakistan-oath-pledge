import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { motion } from "framer-motion";
import QRCode from "qrcode";
import { allPledges, type Pledge } from "@/lib/pledge-store";
import { downloadCertificate } from "@/lib/certificate";
import { useMounted } from "@/hooks/use-mounted";
import { CheckCircle2, Download, Share2, Copy, Sparkles } from "lucide-react";

export const Route = createFileRoute("/success")({
  validateSearch: (s: Record<string, unknown>) => ({ id: String(s.id ?? "") }),
  head: () => ({
    meta: [{ title: "Pledge Submitted — Pakistan Pledge" }],
  }),
  component: SuccessPage,
});

function SuccessPage() {
  const { id } = Route.useSearch();
  const mounted = useMounted();
  const pledge = useMemo<Pledge | undefined>(
    () => (mounted ? allPledges().find((p) => p.id === id) : undefined),
    [id, mounted],
  );
  const [qr, setQr] = useState<string>("");
  const [copied, setCopied] = useState(false);

  const verifyUrl =
    typeof window !== "undefined" ? `${window.location.origin}/verify?id=${id}` : "";

  useEffect(() => {
    if (!id) return;
    QRCode.toDataURL(verifyUrl, {
      margin: 1, width: 320,
      color: { dark: "#01411C", light: "#ffffff" },
    }).then(setQr);
  }, [id, verifyUrl]);

  if (!mounted) {
    return <section className="container-page py-24 text-center text-muted-foreground">Loading certificate…</section>;
  }

  if (!pledge) {
    return (
      <section className="container-page py-24 text-center">
        <h1 className="display text-3xl text-primary font-bold">Pledge not found</h1>
        <p className="mt-3 text-muted-foreground">We couldn't find that pledge on this device.</p>
        <Link to="/pledge" className="mt-6 inline-block rounded-full gradient-green px-6 py-3 text-sm text-primary-foreground">
          Take the pledge
        </Link>
      </section>
    );
  }

  return (
    <section className="container-page py-14 md:py-20">
      <motion.div
        initial={{ opacity: 0, y: 24 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="text-center max-w-2xl mx-auto"
      >
        <div className="inline-flex items-center gap-2 rounded-full bg-flag-green/10 text-flag-green px-3 py-1 text-xs font-medium">
          <Sparkles className="h-3.5 w-3.5" /> Pakistan Zindabad
        </div>
        <h1 className="display mt-5 text-4xl md:text-6xl font-bold text-primary leading-tight">
          Thank you, {pledge.fullName.split(" ")[0]}.
        </h1>
        <p className="mt-4 text-muted-foreground text-lg">
          Your pledge has been recorded. Your official certificate is ready to download.
        </p>
      </motion.div>

      <div className="mt-12 grid lg:grid-cols-12 gap-8 items-start">
        <motion.div
          initial={{ opacity: 0, scale: 0.96 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.6, delay: 0.1 }}
          className="lg:col-span-7 rounded-2xl border bg-card p-8 shadow-elegant ring-gold"
        >
          <div className="text-xs uppercase tracking-widest text-flag-green font-semibold">
            Pledge Receipt
          </div>
          <div className="mt-4 grid sm:grid-cols-2 gap-5">
            <Info label="Pledge ID" value={pledge.id} mono />
            <Info label="Issued" value={new Date(pledge.createdAt).toLocaleString("en-GB")} />
            <Info label="Full Name" value={pledge.fullName} />
            <Info label="Province" value={pledge.province} />
            <Info label="City" value={pledge.city} />
            <Info label="Status" value="Verified" badge />
          </div>

          <div className="mt-7 flex flex-wrap gap-3">
            <button
              onClick={() => downloadCertificate(pledge)}
              className="inline-flex items-center gap-2 rounded-full gradient-green text-primary-foreground px-6 py-3 text-sm font-semibold shadow-elegant"
            >
              <Download className="h-4 w-4" /> Download Certificate (PDF)
            </button>
            <button
              onClick={async () => {
                const text = `I have taken the Pakistan Pledge & Commitment. Join me in building a better Pakistan. ${verifyUrl}`;
                if (navigator.share) {
                  try { await navigator.share({ title: "Pakistan Pledge", text, url: verifyUrl }); } catch {}
                } else {
                  await navigator.clipboard.writeText(text);
                  setCopied(true);
                  setTimeout(() => setCopied(false), 1800);
                }
              }}
              className="inline-flex items-center gap-2 rounded-full border border-primary/30 px-6 py-3 text-sm font-semibold text-primary hover:bg-primary/5"
            >
              <Share2 className="h-4 w-4" /> Share
            </button>
            <button
              onClick={async () => {
                await navigator.clipboard.writeText(verifyUrl);
                setCopied(true);
                setTimeout(() => setCopied(false), 1500);
              }}
              className="inline-flex items-center gap-2 rounded-full border px-6 py-3 text-sm font-medium text-foreground/80 hover:bg-secondary"
            >
              <Copy className="h-4 w-4" /> {copied ? "Copied" : "Copy verify link"}
            </button>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="lg:col-span-5 rounded-2xl border bg-card p-8 text-center shadow-elegant"
        >
          <div className="text-xs uppercase tracking-widest text-flag-green font-semibold">
            Verification QR
          </div>
          <div className="mt-5 inline-block rounded-xl border-4 border-primary/10 p-3 bg-white">
            {qr && <img src={qr} alt="Verification QR code" className="h-56 w-56" />}
          </div>
          <div className="mt-4 text-xs text-muted-foreground break-all">{verifyUrl}</div>
          <div className="mt-5 inline-flex items-center gap-2 text-xs text-flag-green">
            <CheckCircle2 className="h-4 w-4" /> Authentic — verifiable nationwide
          </div>
        </motion.div>
      </div>
    </section>
  );
}

function Info({
  label, value, mono, badge,
}: { label: string; value: string; mono?: boolean; badge?: boolean }) {
  return (
    <div>
      <div className="text-[10px] uppercase tracking-widest text-muted-foreground">{label}</div>
      {badge ? (
        <div className="mt-1.5 inline-flex items-center gap-1.5 rounded-full bg-flag-green/10 text-flag-green text-xs font-semibold px-2.5 py-1">
          <CheckCircle2 className="h-3.5 w-3.5" /> {value}
        </div>
      ) : (
        <div className={`mt-1 text-sm font-semibold text-foreground ${mono ? "font-mono" : ""}`}>
          {value}
        </div>
      )}
    </div>
  );
}
