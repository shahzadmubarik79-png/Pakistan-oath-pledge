import { useEffect, useState } from "react";

/** Returns true after first client mount — use to gate client-only data. */
export function useMounted() {
  const [m, setM] = useState(false);
  useEffect(() => setM(true), []);
  return m;
}
