import jsPDF from "jspdf";
import QRCode from "qrcode";
import type { Pledge } from "./pledge-store";

const GREEN: [number, number, number] = [1, 65, 28];
const GREEN_DEEP: [number, number, number] = [0, 90, 50];
const GOLD: [number, number, number] = [184, 134, 11];
const GOLD_SOFT: [number, number, number] = [212, 175, 55];
const INK: [number, number, number] = [38, 38, 38];
const MUTED: [number, number, number] = [120, 120, 120];
const PAPER: [number, number, number] = [252, 250, 244];
const MAP_TINT: [number, number, number] = [220, 235, 224];
const FLAG_TINT: [number, number, number] = [232, 244, 234];

// Simplified Pakistan border outline (lng, lat)
const PAK_OUTLINE: [number, number][] = [
  [74.9, 37.0], [73.9, 36.9], [72.6, 36.8], [71.6, 36.5], [71.1, 35.3],
  [70.9, 34.0], [69.9, 33.1], [69.3, 31.9], [68.7, 31.6], [67.8, 31.3],
  [66.4, 30.9], [65.0, 29.5], [62.4, 28.0], [62.3, 26.6], [62.9, 25.2],
  [64.2, 25.1], [66.3, 25.4], [67.3, 24.9], [67.9, 24.2], [68.7, 23.7],
  [70.0, 24.1], [70.6, 25.7], [71.0, 27.9], [72.5, 28.8], [73.5, 29.8],
  [74.5, 30.4], [74.4, 31.4], [74.8, 32.5], [74.2, 33.4], [73.8, 34.3],
  [74.2, 34.9], [75.4, 35.7], [76.8, 35.9], [77.2, 36.6], [76.0, 37.0],
];

export async function generateCertificatePdf(pledge: Pledge): Promise<jsPDF> {
  const doc = new jsPDF({ orientation: "landscape", unit: "pt", format: "a4" });
  const W = doc.internal.pageSize.getWidth();
  const H = doc.internal.pageSize.getHeight();

  // ===== Background (ivory) =====
  doc.setFillColor(...PAPER);
  doc.rect(0, 0, W, H, "F");

  // ===== Watermark: subtle Pakistan flag panel =====
  // Pale green field across the page, white hoist stripe on left, faint crescent
  doc.setFillColor(...FLAG_TINT);
  doc.rect(0, 0, W, H, "F");
  // Restore ivory in a centered rectangle so flag acts as a soft border tint only
  doc.setFillColor(...PAPER);
  doc.rect(46, 46, W - 92, H - 92, "F");

  // ===== Watermark: Pakistan map silhouette (centered, very light) =====
  drawPakistanMap(doc, W / 2, H / 2 + 8, 340, 300, MAP_TINT);

  // ===== Outer gold border + inner green hairline =====
  doc.setDrawColor(...GOLD);
  doc.setLineWidth(2.4);
  doc.rect(26, 26, W - 52, H - 52);
  doc.setDrawColor(...GOLD_SOFT);
  doc.setLineWidth(0.6);
  doc.rect(33, 33, W - 66, H - 66);
  doc.setDrawColor(...GREEN);
  doc.setLineWidth(0.5);
  doc.rect(40, 40, W - 80, H - 80);

  // ===== Corner ornaments (gold filigree) =====
  drawCornerOrnament(doc, 40, 40, 1, 1);
  drawCornerOrnament(doc, W - 40, 40, -1, 1);
  drawCornerOrnament(doc, 40, H - 40, 1, -1);
  drawCornerOrnament(doc, W - 40, H - 40, -1, -1);

  // ===== Header crest =====
  // A small green-gold roundel with crescent + star
  const crestX = W / 2;
  const crestY = 86;
  doc.setFillColor(...GOLD);
  doc.circle(crestX, crestY, 22, "F");
  doc.setFillColor(...GREEN);
  doc.circle(crestX, crestY, 18, "F");
  // Crescent
  doc.setFillColor(255, 255, 255);
  doc.circle(crestX - 2, crestY, 10, "F");
  doc.setFillColor(...GREEN);
  doc.circle(crestX + 2, crestY - 1, 8.5, "F");
  // Star
  doc.setFillColor(255, 255, 255);
  drawStar(doc, crestX + 5, crestY - 3, 3.2, 1.4);

  // Brand line
  doc.setFont("times", "bold");
  doc.setFontSize(10);
  doc.setTextColor(...GOLD);
  doc.text("ISLAMIC  REPUBLIC  OF  PAKISTAN", W / 2, 128, { align: "center" });

  doc.setFont("times", "italic");
  doc.setFontSize(9);
  doc.setTextColor(...MUTED);
  doc.text("National Pledge & Commitment Initiative", W / 2, 142, { align: "center" });

  // ===== Title =====
  doc.setFont("times", "bold");
  doc.setFontSize(40);
  doc.setTextColor(...GREEN);
  doc.text("Certificate of Commitment", W / 2, 200, { align: "center" });

  // Title underline with gold diamond
  doc.setDrawColor(...GOLD);
  doc.setLineWidth(0.8);
  doc.line(W / 2 - 200, 218, W / 2 - 14, 218);
  doc.line(W / 2 + 14, 218, W / 2 + 200, 218);
  doc.setFillColor(...GOLD);
  drawDiamond(doc, W / 2, 218, 5);

  // ===== Presented to =====
  doc.setFont("times", "italic");
  doc.setFontSize(13);
  doc.setTextColor(...MUTED);
  doc.text("This certificate is proudly presented to", W / 2, 258, { align: "center" });

  doc.setFont("times", "bold");
  doc.setFontSize(34);
  doc.setTextColor(...INK);
  doc.text(pledge.fullName, W / 2, 305, { align: "center" });

  // Hairline under the name
  const nameMaxW = Math.min(560, W - 240);
  doc.setDrawColor(...GOLD_SOFT);
  doc.setLineWidth(0.5);
  doc.line(W / 2 - nameMaxW / 2, 318, W / 2 + nameMaxW / 2, 318);

  if (pledge.fatherName) {
    doc.setFont("times", "italic");
    doc.setFontSize(10.5);
    doc.setTextColor(...MUTED);
    doc.text(`S/O ${pledge.fatherName}`, W / 2, 333, { align: "center" });
  }

  // ===== Body text =====
  doc.setFont("times", "normal");
  doc.setFontSize(12);
  doc.setTextColor(...INK);
  const body1 = "In recognition of the solemn pledge taken in service of the nation —";
  const body2 = "to uphold unity, honesty, education, the environment, and the progress";
  const body3 = `of Pakistan. Issued from ${pledge.city}, ${pledge.province}.`;
  doc.text(body1, W / 2, 365, { align: "center" });
  doc.text(body2, W / 2, 382, { align: "center" });
  doc.text(body3, W / 2, 399, { align: "center" });

  // ===== Signature blocks =====
  const sigY = H - 110;
  doc.setDrawColor(...INK);
  doc.setLineWidth(0.5);
  doc.line(110, sigY, 290, sigY);
  doc.line(W - 290, sigY, W - 110, sigY);

  doc.setFont("times", "bold");
  doc.setFontSize(10);
  doc.setTextColor(...INK);
  doc.text("Authorized Signatory", 200, sigY + 14, { align: "center" });
  doc.text("Date of Issuance", W - 200, sigY + 14, { align: "center" });

  doc.setFont("times", "italic");
  doc.setFontSize(9);
  doc.setTextColor(...MUTED);
  doc.text("Pakistan Pledge Initiative", 200, sigY + 28, { align: "center" });
  doc.text(
    new Date(pledge.createdAt).toLocaleDateString("en-GB", {
      day: "2-digit", month: "long", year: "numeric",
    }),
    W - 200, sigY + 28, { align: "center" },
  );

  // ===== Gold wax seal (center bottom) =====
  const sealX = W / 2;
  const sealY = sigY + 6;
  doc.setFillColor(...GOLD);
  doc.circle(sealX, sealY, 26, "F");
  doc.setFillColor(...GOLD_SOFT);
  doc.circle(sealX, sealY, 22, "F");
  doc.setDrawColor(255, 255, 255);
  doc.setLineWidth(0.8);
  doc.circle(sealX, sealY, 18);
  doc.setFont("times", "bold");
  doc.setFontSize(7);
  doc.setTextColor(255, 255, 255);
  doc.text("OFFICIAL", sealX, sealY - 2, { align: "center" });
  doc.text("SEAL", sealX, sealY + 8, { align: "center" });

  // ===== QR + ID (bottom right inner area) =====
  const verifyUrl = `${typeof window !== "undefined" ? window.location.origin : ""}/verify?id=${pledge.id}`;
  const qrDataUrl = await QRCode.toDataURL(verifyUrl, {
    margin: 0, width: 240,
    color: { dark: "#01411C", light: "#fcfaf4" },
  });
  const qrSize = 58;
  const qrX = W - 60 - qrSize;
  const qrY = H - 60 - qrSize;
  doc.setDrawColor(...GOLD_SOFT);
  doc.setLineWidth(0.6);
  doc.rect(qrX - 4, qrY - 4, qrSize + 8, qrSize + 8);
  doc.addImage(qrDataUrl, "PNG", qrX, qrY, qrSize, qrSize);
  doc.setFont("helvetica", "normal");
  doc.setFontSize(7);
  doc.setTextColor(...MUTED);
  doc.text("Scan to verify", qrX + qrSize / 2, qrY - 8, { align: "center" });

  // Pledge ID (bottom-left)
  doc.setFont("helvetica", "bold");
  doc.setFontSize(8);
  doc.setTextColor(...GREEN_DEEP);
  doc.text("CERTIFICATE No.", 60, H - 70);
  doc.setFont("helvetica", "normal");
  doc.setFontSize(10);
  doc.setTextColor(...INK);
  doc.text(pledge.id, 60, H - 56);

  return doc;
}

// ===== Helpers =====

function drawPakistanMap(
  doc: jsPDF,
  cx: number,
  cy: number,
  maxW: number,
  maxH: number,
  fill: [number, number, number],
) {
  const lngs = PAK_OUTLINE.map((p) => p[0]);
  const lats = PAK_OUTLINE.map((p) => p[1]);
  const lngMin = Math.min(...lngs), lngMax = Math.max(...lngs);
  const latMin = Math.min(...lats), latMax = Math.max(...lats);
  const sx = maxW / (lngMax - lngMin);
  const sy = maxH / (latMax - latMin);
  const s = Math.min(sx, sy);
  const ox = cx - ((lngMin + lngMax) / 2) * s;
  const oy = cy + ((latMin + latMax) / 2) * s;
  const pts = PAK_OUTLINE.map(([lng, lat]) => [ox + lng * s, oy - lat * s] as [number, number]);

  doc.setFillColor(...fill);
  doc.setDrawColor(fill[0] - 18, fill[1] - 12, fill[2] - 18);
  doc.setLineWidth(0.6);
  const deltas = pts.slice(1).map((p, i) => [p[0] - pts[i][0], p[1] - pts[i][1]] as [number, number]);
  doc.lines(deltas, pts[0][0], pts[0][1], [1, 1], "FD", true);
}

function drawCornerOrnament(doc: jsPDF, x: number, y: number, sx: number, sy: number) {
  doc.setDrawColor(...GOLD);
  doc.setLineWidth(0.8);
  // L-shaped accent
  doc.line(x + sx * 6, y + sy * 6, x + sx * 50, y + sy * 6);
  doc.line(x + sx * 6, y + sy * 6, x + sx * 6, y + sy * 50);
  doc.setLineWidth(0.4);
  doc.line(x + sx * 10, y + sy * 10, x + sx * 36, y + sy * 10);
  doc.line(x + sx * 10, y + sy * 10, x + sx * 10, y + sy * 36);
  // Dot accents
  doc.setFillColor(...GOLD);
  doc.circle(x + sx * 6, y + sy * 6, 1.6, "F");
  doc.circle(x + sx * 50, y + sy * 6, 1.2, "F");
  doc.circle(x + sx * 6, y + sy * 50, 1.2, "F");
}

function drawStar(doc: jsPDF, cx: number, cy: number, outer: number, inner: number) {
  const pts: [number, number][] = [];
  for (let i = 0; i < 10; i++) {
    const r = i % 2 === 0 ? outer : inner;
    const a = (Math.PI / 5) * i - Math.PI / 2;
    pts.push([cx + r * Math.cos(a), cy + r * Math.sin(a)]);
  }
  const deltas = pts.slice(1).map((p, i) => [p[0] - pts[i][0], p[1] - pts[i][1]] as [number, number]);
  doc.lines(deltas, pts[0][0], pts[0][1], [1, 1], "F", true);
}

function drawDiamond(doc: jsPDF, cx: number, cy: number, r: number) {
  doc.lines(
    [[r, -r], [r, r], [-r, r], [-r, -r]],
    cx - r, cy, [1, 1], "F", true,
  );
}

export async function downloadCertificate(pledge: Pledge) {
  const doc = await generateCertificatePdf(pledge);
  doc.save(`Pakistan-Pledge-${pledge.id}.pdf`);
}
