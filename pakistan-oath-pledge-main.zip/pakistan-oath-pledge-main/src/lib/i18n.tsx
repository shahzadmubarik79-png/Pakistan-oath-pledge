import { createContext, useContext, useEffect, useState, type ReactNode } from "react";

export type Lang = "en" | "ur";

const DICT = {
  en: {
    "nav.home": "Home",
    "nav.goals": "National Goals",
    "nav.wall": "Pledge Wall",
    "nav.verify": "Verify",
    "nav.about": "About",
    "cta.take": "Take The Pledge",
    "hero.badge": "A national initiative for every Pakistani",
    "hero.title1": "Pakistan",
    "hero.title2": "Pledge & ",
    "hero.title3": "Commitment",
    "hero.desc": "Join millions of Pakistanis in building a stronger, cleaner, educated and united Pakistan. Take the pledge — receive your official certificate.",
    "hero.viewGoals": "View National Goals",
    "hero.learnMore": "Learn More",
    "hero.bullet1": "Verified Certificate",
    "hero.bullet2": "QR Authentication",
    "hero.bullet3": "Free to Pledge",
    "pledge.quote": "I solemnly pledge that I will contribute positively towards the development, prosperity, unity, peace and progress of Pakistan. I will respect the law, protect the environment, promote education, support my community, and serve my country with honesty and dedication.",
    "pledge.badge": "The National Pledge",
    "pledge.signNow": "Sign now",
    "stats.total": "Total Pledges",
    "stats.verified": "Verified Citizens",
    "stats.cities": "Participating Cities",
    "stats.provinces": "Provinces",
    "stats.today": "Today's Pledges",
    "lang.label": "Language",
    "lang.en": "English",
    "lang.ur": "اردو",
    "cert.title": "CERTIFICATE OF APPRECIATION",
    "cert.to": "To",
    "cert.body1": "In appreciation of your participation and contribution",
    "cert.body2": "in the",
    "cert.name": "Pledge and Commitment",
    "cert.sub": "National Initiative",
    "cert.wish": "Wishing you continued progress and success",
    "cert.brand": "PLEDGE & COMMITMENT",
  },
  ur: {
    "nav.home": "صفحہ اول",
    "nav.goals": "قومی اہداف",
    "nav.wall": "وعدہ دیوار",
    "nav.verify": "تصدیق",
    "nav.about": "تعارف",
    "cta.take": "عہد کریں",
    "hero.badge": "ہر پاکستانی کے لیے ایک قومی اقدام",
    "hero.title1": "پاکستان",
    "hero.title2": "عہد و ",
    "hero.title3": "وعدہ",
    "hero.desc": "لاکھوں پاکستانیوں کے ساتھ مل کر ایک مضبوط، صاف، تعلیم یافتہ اور متحد پاکستان کی تعمیر میں شامل ہوں۔ عہد کریں — اپنا سرکاری سرٹیفکیٹ حاصل کریں۔",
    "hero.viewGoals": "قومی اہداف دیکھیں",
    "hero.learnMore": "مزید جانیں",
    "hero.bullet1": "تصدیق شدہ سرٹیفکیٹ",
    "hero.bullet2": "کیو آر تصدیق",
    "hero.bullet3": "مفت عہد",
    "pledge.quote": "میں پوری سنجیدگی سے عہد کرتا ہوں کہ میں پاکستان کی ترقی، خوشحالی، اتحاد، امن اور بہتری کے لیے مثبت کردار ادا کروں گا۔ میں قانون کا احترام، ماحول کا تحفظ، تعلیم کا فروغ، اپنی برادری کی مدد، اور اپنے ملک کی ایمانداری سے خدمت کروں گا۔",
    "pledge.badge": "قومی عہد",
    "pledge.signNow": "ابھی دستخط کریں",
    "stats.total": "کل وعدے",
    "stats.verified": "تصدیق شدہ شہری",
    "stats.cities": "شریک شہر",
    "stats.provinces": "صوبے",
    "stats.today": "آج کے وعدے",
    "lang.label": "زبان",
    "lang.en": "English",
    "lang.ur": "اردو",
    "cert.title": "اعزازی سرٹیفکیٹ",
    "cert.to": "بنام",
    "cert.body1": "آپ کی شرکت اور خدمات کے اعتراف میں",
    "cert.body2": "بسلسلہ",
    "cert.name": "عہد و وعدہ",
    "cert.sub": "قومی اقدام",
    "cert.wish": "آپ کی مسلسل ترقی و کامیابی کے لیے نیک خواہشات",
    "cert.brand": "PLEDGE & COMMITMENT",
  },
} as const;

export type Key = keyof typeof DICT["en"];

const Ctx = createContext<{ lang: Lang; setLang: (l: Lang) => void; t: (k: Key) => string }>({
  lang: "en",
  setLang: () => {},
  t: (k) => k,
});

export function I18nProvider({ children }: { children: ReactNode }) {
  const [lang, setLangState] = useState<Lang>("en");
  useEffect(() => {
    const saved = (typeof window !== "undefined" && (localStorage.getItem("pp-lang") as Lang)) || "en";
    setLangState(saved);
  }, []);
  useEffect(() => {
    if (typeof document !== "undefined") {
      document.documentElement.lang = lang;
      document.documentElement.dir = lang === "ur" ? "rtl" : "ltr";
    }
  }, [lang]);
  const setLang = (l: Lang) => {
    setLangState(l);
    if (typeof window !== "undefined") localStorage.setItem("pp-lang", l);
  };
  const t = (k: Key) => DICT[lang][k] ?? DICT.en[k] ?? k;
  return <Ctx.Provider value={{ lang, setLang, t }}>{children}</Ctx.Provider>;
}

export function useI18n() {
  return useContext(Ctx);
}
