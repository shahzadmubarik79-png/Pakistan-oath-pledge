import { Link } from "@tanstack/react-router";
import { Menu, X, Globe } from "lucide-react";
import { useState } from "react";
import { useI18n, type Lang, type Key } from "@/lib/i18n";

export function SiteHeader() {
  const [open, setOpen] = useState(false);
  const { lang, setLang, t } = useI18n();

  const nav: { to: string; key: Key }[] = [
    { to: "/", key: "nav.home" },
    { to: "/goals", key: "nav.goals" },
    { to: "/pledge-wall", key: "nav.wall" },
    { to: "/verify", key: "nav.verify" },
    { to: "/about", key: "nav.about" },
  ];

  const LangToggle = () => (
    <div className="inline-flex items-center rounded-full border border-primary/20 bg-background/80 p-0.5 text-xs font-semibold">
      <Globe className="h-3.5 w-3.5 mx-1.5 text-primary/70" />
      {(["en", "ur"] as Lang[]).map((l) => (
        <button
          key={l}
          onClick={() => setLang(l)}
          className={`px-2.5 py-1 rounded-full transition-colors ${
            lang === l ? "gradient-green text-primary-foreground" : "text-foreground/70 hover:text-primary"
          }`}
          aria-pressed={lang === l}
        >
          {l === "en" ? "EN" : "اردو"}
        </button>
      ))}
    </div>
  );

  return (
    <header className="sticky top-0 z-40 border-b border-border/60 bg-background/85 backdrop-blur-md">
      <div className="container-page flex h-16 items-center justify-between">
        <Link to="/" className="flex items-center gap-3 group">
          <div className="relative h-9 w-9 rounded-md overflow-hidden ring-gold gradient-green flex items-center justify-center">
            <span className="text-primary-foreground font-display text-lg">☪</span>
          </div>
          <div className="leading-tight">
            <div className="font-display text-[15px] text-primary font-bold tracking-tight">
              Pakistan Pledge
            </div>
            <div className="text-[10px] uppercase tracking-[0.18em] text-muted-foreground">
              & Commitment
            </div>
          </div>
        </Link>

        <nav className="hidden md:flex items-center gap-7">
          {nav.map((n) => (
            <Link
              key={n.to}
              to={n.to}
              className="text-sm text-foreground/80 hover:text-primary transition-colors"
              activeProps={{ className: "text-primary font-semibold" }}
            >
              {t(n.key)}
            </Link>
          ))}
        </nav>

        <div className="flex items-center gap-2">
          <div className="hidden md:block"><LangToggle /></div>
          <Link
            to="/pledge"
            className="hidden md:inline-flex items-center justify-center rounded-full gradient-green text-primary-foreground px-5 py-2.5 text-sm font-semibold ring-gold hover:opacity-95 transition-opacity"
          >
            {t("cta.take")}
          </Link>
          <button
            type="button"
            className="md:hidden inline-flex items-center justify-center w-10 h-10 rounded-md border"
            onClick={() => setOpen((v) => !v)}
            aria-label="Toggle navigation"
          >
            {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>
      </div>

      {open && (
        <div className="md:hidden border-t bg-background">
          <div className="container-page py-3 flex flex-col gap-2">
            {nav.map((n) => (
              <Link
                key={n.to}
                to={n.to}
                onClick={() => setOpen(false)}
                className="py-2 text-sm text-foreground/80"
                activeProps={{ className: "text-primary font-semibold" }}
              >
                {t(n.key)}
              </Link>
            ))}
            <div className="pt-2"><LangToggle /></div>
            <Link
              to="/pledge"
              onClick={() => setOpen(false)}
              className="mt-2 inline-flex items-center justify-center rounded-full gradient-green text-primary-foreground px-5 py-2.5 text-sm font-semibold"
            >
              {t("cta.take")}
            </Link>
          </div>
        </div>
      )}
    </header>
  );
}
