import { Link } from "@tanstack/react-router";

export function SiteFooter() {
  return (
    <footer className="mt-24 border-t border-border/60 bg-gradient-to-b from-background to-secondary/40">
      <div className="container-page py-14 grid gap-10 md:grid-cols-4">
        <div className="md:col-span-2">
          <div className="flex items-center gap-3">
            <div className="h-9 w-9 rounded-md gradient-green ring-gold flex items-center justify-center text-primary-foreground font-display">
              ☪
            </div>
            <div className="font-display text-lg text-primary font-bold">
              Pakistan Pledge &amp; Commitment
            </div>
          </div>
          <p className="mt-4 max-w-md text-sm text-muted-foreground leading-relaxed">
            A national initiative inviting every Pakistani to pledge their
            commitment to unity, education, environment, and the prosperity of
            our homeland.
          </p>
          <p className="mt-4 text-xs text-muted-foreground">
            Email:{" "}
            <a className="text-primary" href="mailto:info@pakistanpledge.pk">
              info@pakistanpledge.pk
            </a>
          </p>
        </div>

        <div>
          <div className="text-xs uppercase tracking-widest text-primary font-semibold mb-3">
            Navigate
          </div>
          <ul className="space-y-2 text-sm">
            <li><Link to="/" className="hover:text-primary">Home</Link></li>
            <li><Link to="/about" className="hover:text-primary">About</Link></li>
            <li><Link to="/goals" className="hover:text-primary">National Goals</Link></li>
            <li><Link to="/pledge" className="hover:text-primary">Take Pledge</Link></li>
            <li><Link to="/pledge-wall" className="hover:text-primary">Pledge Wall</Link></li>
          </ul>
        </div>

        <div>
          <div className="text-xs uppercase tracking-widest text-primary font-semibold mb-3">
            Resources
          </div>
          <ul className="space-y-2 text-sm">
            <li><Link to="/verify" className="hover:text-primary">Verify Certificate</Link></li>
            <li><a href="#" className="hover:text-primary">Privacy Policy</a></li>
            <li><a href="#" className="hover:text-primary">Terms &amp; Conditions</a></li>
            <li><a href="#" className="hover:text-primary">FAQ</a></li>
          </ul>
        </div>
      </div>

      <div className="border-t border-border/60">
        <div className="container-page py-5 flex flex-col md:flex-row items-center justify-between gap-2 text-xs text-muted-foreground">
          <div>© {new Date().getFullYear()} Pakistan Pledge &amp; Commitment. All Rights Reserved.</div>
          <div className="flex items-center gap-2">
            <span className="inline-block h-2 w-2 rounded-full bg-flag-green" />
            <span>Pakistan Zindabad</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
